angular.module('myApp', [
    'ngRoute',
    'mobile-angular-ui',
	'btford.socket-io'
]).config(function($routeProvider) {
    $routeProvider.when('/', {
        templateUrl: 'home.html',
        controller: 'Home'
    });
}).factory('mySocket', function (socketFactory) {
	var myIoSocket = io.connect('/webapp');	//Tên namespace webapp

	mySocket = socketFactory({
		ioSocket: myIoSocket
	});
	return mySocket;
	
/////////////////////// Những dòng code ở trên phần này là phần cài đặt, các bạn hãy đọc thêm về angularjs để hiểu, cái này không nhảy cóc được nha!
}).controller('Home', function($scope, mySocket) {
	////Khu 1 -- Khu cài đặt tham số 
    //cài đặt một số tham số test chơi
	//dùng để đặt các giá trị mặc định
    $scope.DieuHoa = "	Chưa có cập nhật dữ liệu Dieu Hoa";
	$scope.TiVi = "	Chưa có cập nhật dữ liệu Tivi";
    $scope.leds_status = [1, 1, 1]
	$scope.fans_status = [1, 1] // khai bao hai cai den voi muc 1 va muc 2 muc 3
	$scope.fanms_status = [1, 1] // khai bao hai cai den voi muc 1 va muc 2 muc 3
	
	
	//$scope.rawDatabat = [4300,4400, 500,1600, 550,550, 500,1650, 500,1650, 500,550, 500,600, 500,1600, 550,550, 500,550, 500,1650, 500,550, 500,600, 500,1600, 550,1600, 550,550, 500,1650, 500,550, 500,600, 500,1600, 500,1650, 550,1600, 500,1600, 550,1600, 550,1600, 500,1650, 500,1600, 550,550, 500,550, 550,550, 500,550, 500,600, 500,550, 500,1650, 500,600, 500,1650, 500,550, 500,550, 550,550, 500,550, 550,550, 500,550, 500,1650, 500,550, 550,1600, 550,1600, 500,1650, 500,1650, 500,1600, 500]  // SAMSUNG B24D3FC0
  
	////Khu 2 -- Cài đặt các sự kiện khi tương tác với người dùng
	//các sự kiện ng-click, nhấn nút
	$scope.updateSensor  = function() {
		mySocket.emit("AIR")
	}
	
	$scope.changeLED = function() {
		console.log("send LED ", $scope.leds_status)
		
		var json = {
			"led": $scope.leds_status
		}
		mySocket.emit("LED", json)
/* 				console.log("send LED ", $scope.rawDatabat
		
		var json = {
			"led": $scope.rawDatabat
		}
		mySocket.emit("LED", json) */
	}
	$scope.changeFAN = function() {
		console.log("send FAN ", $scope.fans_status)
		
		var json = {
			"fan": $scope.fans_status
		}
		mySocket.emit("FAN", json)
	}
	$scope.changeFANM = function() {
		console.log("send FANM ", $scope.fanms_status)
		
		var json = {
			"fanm": $scope.fanms_status
		}
		mySocket.emit("FANM", json)
	}
	////Khu 3 -- Nhận dữ liệu từ Arduno gửi lên (thông qua ESP8266 rồi socket server truyền tải!)
	//các sự kiện từ Arduino gửi lên (thông qua esp8266, thông qua server)
	mySocket.on('AIR', function(json) {
		$scope.DieuHoa = (json.digital == 1) ? "Nhiet độ" : "Có mưa rồi yeah ahihi"
	})
	//Khi nhận được lệnh LED_STATUS
	mySocket.on('LED_STATUS', function(json) {
		//Nhận được thì in ra thôi 
		console.log("recv LED", json)
		$scope.leds_status = json.data
		//Khi nhận được lệnh FAN_STATUS
	})
	mySocket.on('FAN_STATUS', function(json) {
		//Nhận được thì in ra thôi 
		console.log("recv FAN", json)
		$scope.fans_status = json.data
	})	
/* 	mySocket.on('FANM_STATUS', function(json) {
		//Nhận được thì in ra thôi 
		console.log("recv FANM", json)
		$scope.fanms_status = json.data
	})	 */
	//// Khu 4 -- Những dòng code sẽ được thực thi khi kết nối với Arduino (thông qua socket server)
	mySocket.on('connect', function() {
		console.log("connected")
		mySocket.emit("DIEUHOA") //Cập nhập trạng tháI điều hòa
		mySocket.emit("TIVI") //Cập nhập trạng tháI TI VI
		mySocket.emit("FAN") //Cập nhập trạng tháI QUAT
		mySocket.emit("LED") //Cập nhập trạng tháI ĐÈN
	})
		
});